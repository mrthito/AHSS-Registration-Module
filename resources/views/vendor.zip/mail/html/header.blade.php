@props(['url'])
<tr>
    <td class="header">
        <a href="{{ $url }}" style="display: inline-block;">
            <img src="https://surgerysociety.unipegasusinfotechsolutions.com/wp-content/uploads/2023/01/surgerysociety_logo.png"
                class="logo" alt="Logo">
        </a>
    </td>
</tr>